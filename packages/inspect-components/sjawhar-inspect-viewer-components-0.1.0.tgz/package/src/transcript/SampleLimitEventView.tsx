import type {
  EvalSampleLimit,
  SampleLimitEvent,
} from "@sjawhar/inspect-viewer-common/types";
import clsx from "clsx";
import { FC } from "react";

import { EventPanel } from "./event/EventPanel";
import { TranscriptIcons } from "./icons";
import { EventNode } from "./types";

type EvalSampleLimitType = EvalSampleLimit["type"];
interface SampleLimitEventViewProps {
  eventNode: EventNode<SampleLimitEvent>;
  className?: string | string[];
}

export const SampleLimitEventView: FC<SampleLimitEventViewProps> = ({
  eventNode,
  className,
}) => {
  const resolve_title = (type: EvalSampleLimitType) => {
    switch (type) {
      case "custom":
        return "Custom Limit Exceeded";
      case "time":
        return "Time Limit Exceeded";
      case "message":
        return "Message Limit Exceeded";
      case "token":
        return "Token Limit Exceeded";
      case "operator":
        return "Operator Canceled";
      case "working":
        return "Execution Time Limit Exceeded";
      case "cost":
        return "Cost Limit Exceeded";
    }
  };

  const resolve_icon = (type: EvalSampleLimitType) => {
    switch (type) {
      case "custom":
        return TranscriptIcons.limits.custom;
      case "time":
        return TranscriptIcons.limits.time;
      case "message":
        return TranscriptIcons.limits.messages;
      case "token":
        return TranscriptIcons.limits.tokens;
      case "operator":
        return TranscriptIcons.limits.operator;
      case "working":
        return TranscriptIcons.limits.execution;
      case "cost":
        return TranscriptIcons.limits.cost;
    }
  };

  const title = resolve_title(eventNode.event.type);
  const icon = resolve_icon(eventNode.event.type);

  return (
    <EventPanel
      eventNodeId={eventNode.id}
      title={title}
      icon={icon}
      className={className}
    >
      <div className={clsx("text-size-smaller")}>{eventNode.event.message}</div>
    </EventPanel>
  );
};
